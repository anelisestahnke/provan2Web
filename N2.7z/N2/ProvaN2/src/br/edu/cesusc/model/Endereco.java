package br.edu.cesusc.model;

/**
 * Esta classe model (Java Bean) representa uma entidade de endere�o
 */

public class Endereco {
	protected int idEndereco;
	protected String bairro;
	protected String cidade;
	protected int cep;
	protected String estado;  
	protected String logradoro;
	protected int numero;
	
	public Endereco() {
		super();
	}

	public Endereco(int idEndereco, String bairro, String cidade, int cep, String estado, String logradoro,int numero ) {
		super();
		this.idEndereco = idEndereco;
		this.bairro = bairro;
		this.cidade = cidade;
		this.estado = estado;
		this.logradoro = logradoro;
		this.numero = numero;
	}

	public Endereco(String bairro, String cidade, int cep, String estado, String logradoro,int numero) {
		super();
		this.bairro = bairro;
		this.cidade = cidade;
		this.estado = estado;
		this.logradoro = logradoro;
		this.numero = numero;
	}

	public int getId() {
		return idEndereco;
	}

	public void setId(int idEndereco) {
		this.idEndereco = idEndereco;
	}

	public String getBairro() {
		return bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public int getCep() {
		return cep;
	}
	public String getEstado() {
		return estado;
	}
	public int getNumero() {
		return numero;
	}
	public String getLogradoro() {
		return logradoro;
	}
}
