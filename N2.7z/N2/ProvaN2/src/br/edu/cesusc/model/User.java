package br.edu.cesusc.model;

/**
 * Esta classe model (Java Bean) representa uma entidade de cliente
 */

public class User {
	protected int idCliente;
	protected String nome;
	protected int matricula;
	protected int idEndereco;
	protected int idModalidade;
	
	public User() {
		super();
	}

	public User(int idCliente, String nome, int matricula, int idEndereco, int idModalidade) {
		super();
		this.idCliente = idCliente;
		this.nome = nome;
		this.matricula = matricula;
		this.idEndereco = idEndereco;
	}

	public User(String nome, int matricula) {
		super();
		this.nome = nome;
		this.matricula = matricula;
		this.matricula = matricula;
	}

	public int getId() {
		return idCliente;
	}

	public void setId(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	
	public int getidEndereco() {
		return idEndereco;
	}

	public void setidEndereco(int idEndereco) {
		this.idEndereco = idEndereco;
	}
	
	public int getidModalidade() {
		return idModalidade;
	}

	public void setidModalidade(int idModalidade) {
		this.idModalidade = idModalidade;
	}

}
