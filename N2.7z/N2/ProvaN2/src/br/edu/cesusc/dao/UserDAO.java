package br.edu.cesusc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.edu.cesusc.model.User;

/**
 * Esta classe DAO permite realizar as opera��es de inser��o, leitura,
 * atualiza��o e exclus�o dos registros da tabela 'users' do banco de dados
 * 'demo'
 */

public class UserDAO {
	// URL de conex�o do banco de dados 'demo' MySQL
	private String jdbcURL = "jdbc:mysql://localhost/demo?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&useSSL=false";
	// Nome de usu�rio 'root' para acesso ao banco de dados MySQL
	private String jdbcUsername = "n2web";
	// Senha do usu�rio 'root' para acesso ao banco de dados MySQL
	private String jdbcPassword = "Anelise1988";

	private static final String INSERT_USERS_SQL = "INSERT INTO users" + "  (nome, matricula,idEndereco, idModalidade) VALUES "
			+ " (?, ?, ?);";
	private static final String SELECT_USER_BY_ID = "SELECT idCliente, nome, matricula, idEndereco, idModalidade FROM users WHERE id = ?";
	private static final String SELECT_ALL_USERS = "SELECT * FROM clientes";
	private static final String DELETE_USERS_SQL = "DELETE FROM clientes WHERE idCliente = ?;";
	private static final String UPDATE_USERS_SQL = "UPDATE clientes SET nome = ?, matricula = ? idEndereco = ?, idModalidade = ? WHERE idCliente = ?;";

	public UserDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(User user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// Fecha a conex�o automaticamente ap�s a utiliza��o
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
			preparedStatement.setString(1, user.getNome());
			preparedStatement.setInt(2, user.getMatricula());
			preparedStatement.setInt(3, user.getidEndereco());
			preparedStatement.setInt(4, user.getidModalidade());
			
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public User selectUser(int idCliente) {
		User user = null;

		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID)) {
			preparedStatement.setInt(1, idCliente);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				String nome = rs.getString("nome");
				int matricula = rs.getInt("matricula");
				int idEndereco = rs.getInt("endereco");
				int idModalidade = rs.getInt("modalidade");
				user = new User(idCliente, nome, matricula,idEndereco, idModalidade);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<User> selectAllUsers() {
		List<User> users = new ArrayList<>();
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS)) {
			System.out.println(preparedStatement);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				int idCliente = rs.getInt("idCliente");
				String nome = rs.getString("nome");
				int matricula = rs.getInt("matricula");
				nt idEndereco = rs.getInt("endereco");
				int idModalidade = rs.getInt("modalidade");
				users.add(new User(idCliente, nome, matricula,idEndereco, idModalidade));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int idCliente) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(DELETE_USERS_SQL)) {
			System.out.println(preparedStatement);
			preparedStatement.setInt(1, idCliente);
			rowDeleted = preparedStatement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(User user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_USERS_SQL)) {
			System.out.println(preparedStatement);
			preparedStatement.setString(1, user.getNome());
			preparedStatement.setInt(2, user.getMatricula());
			preparedStatement.setInt(3, user.getidEndereco());
			preparedStatement.setInt(4, user.getidModalidade());
			rowUpdated = preparedStatement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException exception) {
		for (Throwable e : exception) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("C�digo do erro: " + ((SQLException) e).getErrorCode());
				System.err.println("Mensagem: " + e.getMessage());
			}
		}

	}
}
